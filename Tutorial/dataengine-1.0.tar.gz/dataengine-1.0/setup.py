from distutils.core import setup

setup(name='dataengine',
      version='1.0',
      description='Holoclean : Data repairing using machine learning',
      author='Holoclean Group',
      author_email='a5heidar@uwaterloo.ca',
      url='https://github.com/thodrek/holoclean',
      py_modules=['dataEngine'],
     )